package com.Techno.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Techno.entity.LeaveEn;

@Repository
public interface LeaveRepo extends JpaRepository<LeaveEn, Long>{

//	@Query("SELECT l.leaveRequestId, l.reason, l.employee.employeeId FROM LeaveEn l WHERE l.employee.employeeId = :employeeId")
	@Query(value = "SELECT * FROM leave_en WHERE leave_en.employee_id = :employeeId", nativeQuery = true)
	List<LeaveEn> findSelectedFieldsByEmployeeId(@Param("employeeId") Long employeeId);
//	@Query(value = "SELECT * FROM leave_en WHERE leave_en.employee_id = ?1", nativeQuery = true)
//	List<LeaveEn> findSelectedFieldsByEmployeeId(Long employeeId);

}
