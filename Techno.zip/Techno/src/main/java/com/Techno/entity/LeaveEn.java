package com.Techno.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.sql.Date;


import com.fasterxml.jackson.annotation.JsonBackReference;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class LeaveEn {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long leaveRequestId;
    private String leaveType;
    private Date startDate;
    private Date endDate;
    private String reason;
    private String leaveStatus;
    
    
    @ManyToOne()
    @JsonBackReference
    @JoinColumn(name="employee_id")
    private Employee employee;
    
    
    public void setTime(LocalDate localDate) {
    	this.startDate = Date.valueOf(localDate);
    }
    
}
