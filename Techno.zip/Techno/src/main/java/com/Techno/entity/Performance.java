package com.Techno.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Performance {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	 private Long performanceId;
	    private String goalsAndObjectives;
	    private String metricsAndTargets;
	    private double evaluationScores;
	    private String overallPerformanceRating;
	    private String feedbackAndComments;
	    
	    
	    @ManyToOne
	    @JsonBackReference
	    @JoinColumn(name="employee_id")
	    private Employee employee;
}
